
def f(x):
    return 1.0/(x-1)

def g(y):
    return f(y+1)